﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ZooPark.Classes;

namespace ZooPark.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditPage.xaml
    /// </summary>
    public partial class AddEditPage : Page
    {
        private KindOfAnimal KindOfAnimal = new KindOfAnimal();        
        public AddEditPage(KindOfAnimal selectedAnimal)
        {
            InitializeComponent();
            if (selectedAnimal != null)
                KindOfAnimal = selectedAnimal;
            DataContext = KindOfAnimal; // Созданный контекст
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();//Объект ошибка

            if (string.IsNullOrWhiteSpace(KindOfAnimal.Name))
                error.AppendLine("Укажите название");
            if (string.IsNullOrWhiteSpace(KindOfAnimal.FoodConsumption.ToString()))
                error.AppendLine("Укажите сколько ест");
            if (string.IsNullOrWhiteSpace(KindOfAnimal.RoomNumber.ToString()))
                error.AppendLine("Укажите где живёт");
            if (string.IsNullOrWhiteSpace(KindOfAnimal.Quantity.ToString()))
                error.AppendLine("Укажите количесвто");
            if (string.IsNullOrWhiteSpace(KindOfAnimal.IdFamily.ToString()))
                error.AppendLine("Укажите семейство");
            if (string.IsNullOrWhiteSpace(KindOfAnimal.IdContinent.ToString()))
                error.AppendLine("Укажите континент");
            if (string.IsNullOrWhiteSpace(KindOfAnimal.IdComplex.ToString()))
                error.AppendLine("Укажите комплекс");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            //Если пользователь новый
            if (KindOfAnimal.Id == 0)
                ZooparkEntities.GetZoopark().KindOfAnimal.Add(KindOfAnimal);//Добавить его 
            try
            {
                ZooparkEntities.GetZoopark().SaveChanges(); //Сохранить изменения
                MessageBox.Show("Данные сохранены");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }
}
